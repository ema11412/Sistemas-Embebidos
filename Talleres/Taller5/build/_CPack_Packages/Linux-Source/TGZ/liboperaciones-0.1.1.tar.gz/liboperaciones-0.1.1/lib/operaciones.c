#include <math.h>

//Suma
float add(float a, float b) { 
  return a + b;
}

//Resta
float sub(float a, float b) {
  return a - b;
}

//Multiplicacion
float mul(float a, float b) {
  return a * b;
}

//DIvision
float div(float a, float b) {
  return a / b;
}

//Raiz
float square_root(float a) {
  return sqrt(a);
}
